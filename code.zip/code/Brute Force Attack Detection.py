import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.neural_network import BernoulliRBM
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.decomposition import PCA
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization, LSTM
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.utils.class_weight import compute_class_weight
import time

# تابع بارگذاری و پیش‌پردازش داده‌ها


def load_and_preprocess_data(file_paths):
    all_data = [pd.read_csv(file) for file in file_paths]
    full_dataset = pd.concat(all_data, axis=0)
    full_dataset.columns = full_dataset.columns.str.strip()
    full_dataset.drop_duplicates(inplace=True)
    full_dataset.replace([np.inf, -np.inf], np.nan, inplace=True)
    full_dataset.fillna(full_dataset.median(numeric_only=True), inplace=True)

    botnet_attacks = ['FTP-Patator', 'SSH-Patator']

    botnet_data = full_dataset[full_dataset['Label'].isin(botnet_attacks)]

    feature_columns = [
        "Destination Port", "Flow Duration", "Total Fwd Packets", "Total Backward Packets",
        "Total Length of Fwd Packets", "Total Length of Bwd Packets", "Fwd Packet Length Max",
        "Fwd Packet Length Min", "Fwd Packet Length Mean", "Fwd Packet Length Std", "Bwd Packet Length Max",
        "Bwd Packet Length Min", "Bwd Packet Length Mean", "Bwd Packet Length Std", "Flow Bytes/s",
        "Flow Packets/s", "Flow IAT Mean", "Flow IAT Std", "Flow IAT Max", "Flow IAT Min", "Fwd IAT Total",
        "Fwd IAT Mean", "Fwd IAT Std", "Fwd IAT Max", "Fwd IAT Min", "Bwd IAT Total", "Bwd IAT Mean",
        "Bwd IAT Std", "Bwd IAT Max", "Bwd IAT Min", "Fwd PSH Flags", "Bwd PSH Flags", "Fwd URG Flags",
        "Bwd URG Flags", "Fwd Header Length", "Bwd Header Length", "Fwd Packets/s", "Bwd Packets/s",
        "Min Packet Length", "Max Packet Length", "Packet Length Mean", "Packet Length Std",
        "Packet Length Variance", "FIN Flag Count", "SYN Flag Count", "RST Flag Count", "PSH Flag Count",
        "ACK Flag Count", "URG Flag Count", "CWE Flag Count", "ECE Flag Count", "Down/Up Ratio",
        "Average Packet Size", "Avg Fwd Segment Size", "Avg Bwd Segment Size", "Fwd Avg Bytes/Bulk",
        "Fwd Avg Packets/Bulk", "Fwd Avg Bulk Rate", "Bwd Avg Bytes/Bulk", "Bwd Avg Packets/Bulk",
        "Bwd Avg Bulk Rate", "Subflow Fwd Packets", "Subflow Fwd Bytes", "Subflow Bwd Packets",
        "Subflow Bwd Bytes", "Init_Win_bytes_forward", "Init_Win_bytes_backward", "act_data_pkt_fwd",
        "min_seg_size_forward", "Active Mean", "Active Std", "Active Max", "Active Min", "Idle Mean",
        "Idle Std", "Idle Max", "Idle Min"
    ]
    existing_features = [
        col for col in feature_columns if col in botnet_data.columns]
    X = botnet_data[existing_features].values
    y = botnet_data['Label'].values

    # پیش‌پردازش داده‌ها
    X = np.nan_to_num(X, nan=0)
    scaler = MinMaxScaler()
    X = scaler.fit_transform(X)

    encoder = LabelEncoder()
    y = encoder.fit_transform(y)

    return X, y, encoder.classes_

# تعریف DBN با چندین لایه RBM و Logistic Regression


class SimpleDBN:
    def __init__(self, n_components_list, learning_rate=0.1, n_iter_list=None):
        if n_iter_list is None:
            n_iter_list = [10] * len(n_components_list)
        self.rbms = [
            BernoulliRBM(n_components=n, learning_rate=learning_rate,
                         n_iter=n_iter, random_state=42)
            for n, n_iter in zip(n_components_list, n_iter_list)
        ]
        self.classifier = LogisticRegression(max_iter=1000, random_state=42)

    def fit(self, X, y):
        for i, rbm in enumerate(self.rbms):
            print(f"Training RBM Layer {i + 1}/{len(self.rbms)}...")
            X = rbm.fit_transform(X)
        print("Training Logistic Regression Classifier...")
        self.classifier.fit(X, y)

    def predict(self, X):
        for rbm in self.rbms:
            X = rbm.transform(X)
        return self.classifier.predict(X)

# تعریف SVM-IDS با روش سریع


# تعریف SVM-IDS با روش سریع


def svm_ids_fast(X_train, X_test, y_train, y_test):
    print("Performing PCA for dimensionality reduction...")
    pca = PCA(n_components=0.95)
    X_train_pca = pca.fit_transform(X_train)
    X_test_pca = pca.transform(X_test)

    print("Training SVM with fixed parameters...")
    svm_model = SVC(C=1.0, gamma=0.01, kernel='rbf', random_state=42)

    start_time = time.time()
    svm_model.fit(X_train_pca, y_train)
    training_time = time.time() - start_time

    y_pred = svm_model.predict(X_test_pca)

    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(
        y_test, y_pred, average='weighted', zero_division=0)
    recall = recall_score(y_test, y_pred, average='weighted', zero_division=0)
    f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)

    results = {
        "Attack Detection Method": "SVM-IDS",
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1-Score": f1,
        "Training Time (s)": training_time
    }

    return results


# تعریف RNN-IDS بهینه‌شده


def rnn_ids_optimized(X_train, X_test, y_train, y_test, num_classes, max_epochs=5, batch_size=256):
    print("Normalizing and reshaping data for RNN...")
    # استانداردسازی داده‌ها
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    # تغییر شکل داده‌ها برای ورودی RNN
    X_train = X_train.reshape(X_train.shape[0], X_train.shape[1], 1)
    X_test = X_test.reshape(X_test.shape[0], X_test.shape[1], 1)

    # تبدیل برچسب‌ها به دسته‌بندی (one-hot encoding)
    y_train_cat = to_categorical(y_train, num_classes=num_classes)
    y_test_cat = to_categorical(y_test, num_classes=num_classes)

    print("Building optimized RNN model...")
    # تعریف مدل RNN بهینه‌شده
    model = Sequential([
        LSTM(64, input_shape=(X_train.shape[1], 1),
             activation='tanh', return_sequences=True),
        Dropout(0.2),
        LSTM(32, activation='tanh'),
        Dropout(0.2),
        Dense(16, activation='relu'),
        Dense(num_classes, activation='softmax')
    ])

    model.compile(optimizer='adam',
                  loss='categorical_crossentropy', metrics=['accuracy'])

    # آموزش مدل
    print("Training RNN...")
    start_time = time.time()
    model.fit(X_train, y_train_cat, epochs=max_epochs,
              batch_size=batch_size, verbose=1, validation_split=0.2)
    training_time = time.time() - start_time

    # ارزیابی مدل
    y_pred = model.predict(X_test, verbose=0)
    y_pred_classes = np.argmax(y_pred, axis=1)

    # محاسبه معیارهای ارزیابی
    accuracy = accuracy_score(y_test, y_pred_classes)
    precision = precision_score(
        y_test, y_pred_classes, average='weighted', zero_division=0)
    recall = recall_score(y_test, y_pred_classes,
                          average='weighted', zero_division=0)
    f1 = f1_score(y_test, y_pred_classes, average='weighted', zero_division=0)

    results = {
        "Attack Detection Method": "RNN-IDS (Optimized)",
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1-Score": f1,
        "Training Time (s)": training_time
    }

    return results

# تعریف SNN-IDS بهینه‌شده برای جلوگیری از اورفیتینگ


def snn_ids_optimized(X_train, X_test, y_train, y_test, num_classes, max_epochs=20, batch_size=128):
    print("Normalizing data for SNN...")
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    y_train_cat = to_categorical(y_train, num_classes=num_classes)
    y_test_cat = to_categorical(y_test, num_classes=num_classes)

    # محاسبه وزن‌های کلاس
    class_weights = compute_class_weight(
        class_weight='balanced', classes=np.unique(y_train), y=y_train)
    class_weights_dict = {i: weight for i, weight in enumerate(class_weights)}

    print("Building optimized SNN model with increased diversity...")
    model = Sequential([
        Dense(64, activation='relu', input_shape=(X_train.shape[1],),
              kernel_regularizer='l2'),
        BatchNormalization(),
        Dropout(0.6),  # Increased dropout to add randomness
        Dense(32, activation='relu', kernel_regularizer='l2'),
        BatchNormalization(),
        Dropout(0.6),  # Increased dropout
        # Added L1 regularization
        Dense(16, activation='relu', kernel_regularizer='l1'),
        Dense(num_classes, activation='softmax')
    ])

    model.compile(optimizer='adam',
                  loss='categorical_crossentropy', metrics=['accuracy'])

    # استفاده از Early Stopping
    early_stop = EarlyStopping(
        monitor='val_loss', patience=5, restore_best_weights=True)

    print("Training SNN with enhanced diversity...")
    start_time = time.time()
    history = model.fit(X_train, y_train_cat, epochs=max_epochs,
                        batch_size=batch_size, verbose=1, validation_split=0.2, callbacks=[early_stop],
                        class_weight=class_weights_dict)
    training_time = time.time() - start_time

    print("Evaluating SNN...")
    y_pred = model.predict(X_test, verbose=0)
    y_pred_classes = np.argmax(y_pred, axis=1)

    # محاسبه معیارهای ارزیابی
    accuracy = accuracy_score(y_test, y_pred_classes)
    precision = precision_score(
        y_test, y_pred_classes, average='weighted', zero_division=0)
    recall = recall_score(y_test, y_pred_classes,
                          average='weighted', zero_division=0)
    f1 = f1_score(y_test, y_pred_classes, average='weighted', zero_division=0)

    results = {
        "Attack Detection Method": "SNN-IDS (Optimized)",
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1-Score": f1,
        "Training Time (s)": training_time
    }

    return results

# تعریف FNN-IDS بهینه‌شده


def fnn_ids_optimized(X_train, X_test, y_train, y_test, num_classes, max_epochs=20, batch_size=128):
    print("Normalizing data for FNN...")
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    y_train_cat = to_categorical(y_train, num_classes=num_classes)
    y_test_cat = to_categorical(y_test, num_classes=num_classes)

    print("Building FNN model...")
    model = Sequential([
        Dense(128, activation='relu', input_shape=(X_train.shape[1],)),
        BatchNormalization(),
        Dropout(0.5),
        Dense(64, activation='relu'),
        BatchNormalization(),
        Dropout(0.5),
        Dense(32, activation='relu'),
        Dense(num_classes, activation='softmax')
    ])

    model.compile(optimizer='adam',
                  loss='categorical_crossentropy', metrics=['accuracy'])

    print("Training FNN...")
    start_time = time.time()
    history = model.fit(X_train, y_train_cat, epochs=max_epochs,
                        batch_size=batch_size, verbose=1, validation_split=0.2)
    training_time = time.time() - start_time

    print("Evaluating FNN...")
    y_pred = model.predict(X_test, verbose=0)
    y_pred_classes = np.argmax(y_pred, axis=1)

    # محاسبه معیارهای ارزیابی
    accuracy = accuracy_score(y_test, y_pred_classes)
    precision = precision_score(
        y_test, y_pred_classes, average='weighted', zero_division=0)
    recall = recall_score(y_test, y_pred_classes,
                          average='weighted', zero_division=0)
    f1 = f1_score(y_test, y_pred_classes, average='weighted', zero_division=0)

    results = {
        "Attack Detection Method": "FNN-IDS (Optimized)",
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1-Score": f1,
        "Training Time (s)": training_time
    }

    return results


# مسیرهای فایل داده‌ها
file_paths = [
    r"E:\New folder (15)\New folder (3)\New folder (2)\New folder\New folder\downloads\New folder (9)\New folder (3)\New folder\مقالات2\New folder (2)\Monday-WorkingHours.pcap_ISCX.csv",
    r"E:\New folder (15)\New folder (3)\New folder (2)\New folder\New folder\downloads\New folder (9)\New folder (3)\New folder\مقالات2\New folder (2)\Tuesday-WorkingHours.pcap_ISCX.csv",
    r"E:\New folder (15)\New folder (3)\New folder (2)\New folder\New folder\downloads\New folder (9)\New folder (3)\New folder\مقالات2\New folder (2)\Wednesday-workingHours.pcap_ISCX.csv",
    r"E:\New folder (15)\New folder (3)\New folder (2)\New folder\New folder\downloads\New folder (9)\New folder (3)\New folder\مقالات2\New folder (2)\Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv",
    r"E:\New folder (15)\New folder (3)\New folder (2)\New folder\New folder\downloads\New folder (9)\New folder (3)\New folder\مقالات2\New folder (2)\Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv",
    r"E:\New folder (15)\New folder (3)\New folder (2)\New folder\New folder\downloads\New folder (9)\New folder (3)\New folder\مقالات2\New folder (2)\Friday-WorkingHours-Morning.pcap_ISCX.csv",
    r"E:\New folder (15)\New folder (3)\New folder (2)\New folder\New folder\downloads\New folder (9)\New folder (3)\New folder\مقالات2\New folder (2)\Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv",
    r"E:\New folder (15)\New folder (3)\New folder (2)\New folder\New folder\downloads\New folder (9)\New folder (3)\New folder\مقالات2\New folder (2)\Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv"
]

# بارگذاری و پیش‌پردازش داده‌ها
X, y, classes = load_and_preprocess_data(file_paths)
num_classes = len(classes)

# اطمینان از تعادل کلاس‌ها با استفاده از Stratified Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y)

# آموزش مدل DBN
dbn = SimpleDBN(n_components_list=[200, 100],
                n_iter_list=[20, 15], learning_rate=0.1)
print("Training DBN...")
start_time = time.time()
dbn.fit(X_train, y_train)
dbn_training_time = time.time() - start_time

y_pred_dbn = dbn.predict(X_test)
accuracy_dbn = accuracy_score(y_test, y_pred_dbn)
precision_dbn = precision_score(
    y_test, y_pred_dbn, average='weighted', zero_division=0)
recall_dbn = recall_score(
    y_test, y_pred_dbn, average='weighted', zero_division=0)
f1_dbn = f1_score(y_test, y_pred_dbn, average='weighted', zero_division=0)

dbn_results = {
    "Attack Detection Method": "DBN",
    "Accuracy": accuracy_dbn,
    "Precision": precision_dbn,
    "Recall": recall_dbn,
    "F1-Score": f1_dbn,
    "Training Time (s)": dbn_training_time
}

# آموزش مدل SVM
svm_results = svm_ids_fast(X_train, X_test, y_train, y_test)

# آموزش مدل RNN-IDS بهینه‌شده
rnn_results = rnn_ids_optimized(
    X_train, X_test, y_train, y_test, num_classes=num_classes)

# آموزش مدل SNN-IDS بهینه‌شده
snn_results = snn_ids_optimized(
    X_train, X_test, y_train, y_test, num_classes=num_classes, max_epochs=20, batch_size=128)

# آموزش مدل FNN-IDS بهینه‌شده
fnn_results = fnn_ids_optimized(
    X_train, X_test, y_train, y_test, num_classes=num_classes, max_epochs=20, batch_size=128)

# ایجاد DataFrame برای نتایج
results_df = pd.DataFrame(
    [dbn_results, svm_results, rnn_results, snn_results, fnn_results])

# نمایش جدول نتایج به صورت پرینت
print("Attack Detection Results:")
print(results_df)

# خواندن نام مدل‌ها و متریک‌ها
models = results_df['Attack Detection Method']
metrics = ["Accuracy", "Precision", "Recall", "F1-Score"]

# استخراج داده‌ها از DataFrame
data = results_df[metrics].values.T  # متریک‌ها به شکل ردیف‌ها برای رسم نمودار

# تنظیمات نمودار
x = np.arange(len(models))  # موقعیت مدل‌ها روی محور x
width = 0.2  # عرض هر میله

# رنگ‌ها برای هر متریک
colors = ['blue', 'red', 'green', 'purple']

# رسم نمودار
fig, ax = plt.subplots(figsize=(10, 6))

for i, (metric, color) in enumerate(zip(metrics, colors)):
    ax.bar(x + i * width, data[i] * 100, width,
           label=metric, color=color)  # تبدیل به درصد

# تنظیم محور‌ها و برچسب‌ها
ax.set_xlabel("Model", fontsize=12)
ax.set_ylabel("Percentage (%)", fontsize=12)
ax.set_title("  Brute Force Attack Detection", fontsize=14)
ax.set_xticks(x + width * 1.5)  # تنظیم مکان برچسب‌ها
ax.set_xticklabels(models, rotation=45)  # تنظیم نام مدل‌ها زیر محور x
ax.legend(title="Metrics")  # اضافه کردن عنوان به لژند
ax.grid(axis='y', linestyle='--', alpha=0.7)  # خطوط شبکه‌ای محور y

# نمایش نمودار
plt.tight_layout()
plt.show()
